clc;
close all;
clear;
voice = 'Pabna University of Science  and Technology';      % Input voice
sampleRate = 44100;                                         % You can adjust this based on your preferences
NET.addAssembly('System.speech');
mySpeaker=System.Speech.Synthesis.SpeechSynthesizer;
mySpeaker.Rate=3;
mySpeaker.Volume=100;
Speak(mySpeaker, voice);                                    % Text to Speech
% Record the speech
recordTime = 5;                                             % Duration of recording in seconds
recObj = audiorecorder(sampleRate, 16, 1);                  % Start recording
disp('After finished your Recording Speech press Enter');
disp('Recording speech...');
recordblocking(recObj, recordTime);
disp('Recording completed.');
recordedSignal = getaudiodata(recObj);                      % Get the recorded speech signal
audiowrite('recorded_speech.wav', recordedSignal, sampleRate); % Save the recorded speech signal to a file (optional)
time = (0:length(recordedSignal)-1) / sampleRate;
figure;
plot(time, recordedSignal);                                 %  Plot the recorded speech signal
xlabel('Time (s)');
ylabel('Amplitude');
title('Recorded Speech Signal');