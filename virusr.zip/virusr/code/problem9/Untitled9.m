
%Display following image operation in MATLAB/Python -
% i) Threshold image ii) Power enhance contract image iii) High pass image.
clc;clear;close all;

%====================Original image====================
inputImage = imread('4.jpeg');            % Read source Image 
grayImage = rgb2gray(inputImage);         % Convert to gray scale
subplot(221);
imshow(inputImage);                       % Display Original Image
title('Original Image');

%====================Threshold image====================
%inputImage = imread('4.jpeg');            % Read source Image 
%grayImage = rgb2gray(inputImage);         % Convert to gray scale

% Thresholding
thresholdValue = 128;
binaryImage = grayImage > thresholdValue;
subplot(222);
imshow(binaryImage);                       % Display Threshold Image
title('Threshold Image');


%====================Power Enhanced Contrast Image====================
%inputImage = imread('4.jpeg');             % Read source Image 
%grayImage = rgb2gray(inputImage);          % Convert to gray scale
% Power-law transformation
gamma = 1.5;
c = 1;
enhancedImage = c * (double(grayImage) .^ gamma);
enhancedImage = uint8(255 * (enhancedImage / 255).^ (1/gamma));    % Unsigned 8-bit integers, (0 to 255).
subplot(223);
imshow(enhancedImage);                                             % Display Power Enhanced Contrast Image
title('Power Enhanced Contrast Image');

%====================High Pass Imagee====================
%inputImage = imread('4.jpeg');                % Read source Image 
%grayImage = rgb2gray(inputImage);             % Convert to gray scale
laplacianKernel = [0 -1 0; -1 4 -1; 0 -1 0];  % Create a high-pass filter kernel (Laplacian)

% Apply the high-pass filter using convolution
highPassImage = conv2(double(grayImage), laplacianKernel, 'same'); % Convolution
highPassImage = uint8(highPassImage);                              % Unsigned 8-bit integers, (0 to 255)
subplot(224);
imshow(highPassImage);                                             % Power Enhanced Contrast Image
title('High Pass Image');