%Write A MATLAB/Python Program To Identify Horizontal, Vertical Lines From An Image.
clc;
clear;
close all;
%i1=input('Enter image name with location (line1.jpg) :');
getim=imread('LINE3.JPG');         % Read source Image
GI=rgb2gray(getim);                % Convert RGB to Gray scale image 
subplot(2,1,1),imshow(GI);         % Display Gray scale image
title('Input image');

S1=GI;S2=GI;S3=GI;S4=GI;           % Initialize the value of GI
M1=[-1 -1 -1;2 2 2;-1 -1  -1];     % Mask For Horizontal  line
M2=[-1 -1 2;-1 2 -1;2 -1  -1];     % Mask For +45 degree  line
M3=[-1 2 -1;-1 2 -1;-1 2  -1];     % Mask For Vartical  line
M4=[2 -1 -1;-1 2 -1;-1 -1  2];     % Mask For -45 degree  line

%For output image
OutI=GI;
OutI(:,:)=0;                       % Set all the elements of a 2D matrix with 0

%Get size of Extented matrix
l=1;
GIext = wextend(2,'zpd',GI,l);     % wextend(mode, boundary, data, extensionLength)
                                   % wextend(symmetric,Zero-phase Padding,data,number of elements)
Emat=size(GIext);                  % Image Dimension width by height  
Max_r=Emat(1);                     % Assign Width
Max_c=Emat(2);                     % Assign Height

%========== Detect Horinzontal Line ============
for i=1:1:Max_r-2
    for j=1:1:Max_c-2
        x=GIext(i:i+2,j:j+2);     % Get submatrix
        r=M1.*double(x);
        R=sum(sum(r));            % sumRow(sumColumn)
        S1(i,j)=uint8(R);         % Unsigned 8-bit integers, (0 to 255).
   end
end   

%========== Detect +45 Degree Line ============%
OutI(:,:)=0;
for i=1:1:Max_r-2
    for j=1:1:Max_c-2
        x=GIext(i:i+2,j:j+2);     % Get submatrix
        r=M2.*double(x);
        R=sum(sum(r));            % sumRow(sumColumn)
        S2(i,j)=uint8(R);         % Store the R values
   end
end   

%========== Detect Vartical Line ============%
OutI(:,:)=0;
for i=1:1:Max_r-2
    for j=1:1:Max_c-2
        x=GIext(i:i+2,j:j+2);     % Get submatrix
        r=M3.*double(x);
        R=sum(sum(r));
        S3(i,j)=uint8(R);         % Store the R values
   end
end   

%========== Detect -45 Degree Line ============%
for i=1:1:Max_r-2
    for j=1:1:Max_c-2
        x=GIext(i:i+2,j:j+2);     % Get submatrix
        r=M4.*double(x);
        R=sum(sum(r));
        S4(i,j)=uint8(R);         % Store the R values
   end
end   

for i=1:1:Max_r-2
    for j=1:1:Max_c-2
        OutI(i,j)=max(max(S1(i,j),S2(i,j)),max(S3(i,j),S4(i,j))); % Max calculate
    end
end   

K=find(OutI>=250);                 % find with condition
OutI(:)=0;
OutI(K)=255;
subplot(2,1,2);
imshow(OutI),title('Output image.');% Display output image