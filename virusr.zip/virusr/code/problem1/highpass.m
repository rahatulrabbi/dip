
% ***********************  High pass Filter ****************************
clc
clear all;
close all;
%i1=input('image name with location :');     % Get Image from user
inim=imread('fruit-2999796.jpg');            % Read source Image
inim=rgb2gray(inim);                         % Convert RGB to Gray scale image 
subplot(2,1,1),imshow(inim);                 % Display Gray scale image
title('Input Image');
exim=wextend(2,'zpd',inim,1);                % wextend(mode, boundary, data, extensionLength
                                             % wextend(symmetric,Zero-phase Padding,data,number of elements)
mask=[-1 -1 -1; -1 8 -1;-1 -1 -1];           % Laplacian kernel 
[r,c]=size(exim);                            % Image Dimension width by height  
for i=1:1:r-2
   for j=1:1:c-2
      N1=exim(i:i+2,j:j+2);                  % To extract a sub-matrix.
      ele_multi=mask.*double(N1);
      col_sum=sum(ele_multi);                % Column sum
      row_sum=col_sum(1,1)+col_sum(1,2)+col_sum(1,3); %Row sum = (col1+col2+col3)
      ave=row_sum/9;                         % Calculate average
      outim(i,j)=ave;                        % set Desired value
   end
end
hpassim=uint8(outim);                        % Unsigned 8-bit integers, (0 to 255).
subplot(2,1,2),imshow(hpassim);
title('High Pass Filtered Image');