% Write A MATLAB/Python Program To Read Coins.png, Leveling All Coins And Display Area Of All Coins
clc;
clear all;
close all;
coinImage = imread('1.png');          % Read source Image

% Convert the image to binary using a threshold
threshold = graythresh(coinImage);
binaryImage = imbinarize(coinImage, threshold);

% Perform morphological operations to clean up the binary image (remove noise)
binaryImage = imopen(binaryImage, strel('arbitrary', 1));  % strel(shape, parameters); like 'square', 'disk'
binaryImage = bwareaopen(binaryImage, 120);                % removing small objects as bwareaopen(inputImage, minArea);
[labels, numCoin] = bwlabel(binaryImage);                  % Label connected components (coin grains)
areas = zeros(1, numCoin);                                 % Initialize measurement variables
% Calculate measurements for each Coin grain
for i = 1:numCoin
    riceRegion = (labels == i);        
    riceStats = regionprops(riceRegion, 'Area');           % Store the measurements in arrays
    areas(i) = riceStats.Area;                             % Calculate area 
end

% Display the results
fprintf('Number of Coin grains: %d\n', numCoin);           % Print number of coin in console
fprintf('Coin Area measurements:\n');
fprintf('Grain \tArea\n');
for i = 1:numCoin
    fprintf('%d\t%.2f\n', i, areas(i));                    % Print Area in console
end
RGB = label2rgb(labels);
imshow(RGB);                                  % Display the image with Coin grains highlighted
title('Coin Grains');
